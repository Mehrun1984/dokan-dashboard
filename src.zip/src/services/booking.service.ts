import apiClient from '@/lib/axios';

const NAMESPACE = '/core-plugin/v1/booking';

// The full appointment object returned by the server
export interface Appointment {
  id: number;
  service_id: number;
  customer_name: string;
  customer_phone: string;
  date: string;
  time_slot: string;
  status: string;
  customer_id?: number; // Backend might return this after generating the shadow account
}

// The payload sent to create an appointment (Shadow Account Flow)
export interface CreateAppointmentPayload {
  service_id: number;
  customer_name: string;
  customer_phone: string;
  date: string;
  time_slot: string;
}

export const bookingService = {
  // ==========================================
  // FETCHING APPOINTMENTS
  // ==========================================
  getAppointments: async (): Promise<Appointment[]> => {
    const { data } = await apiClient.get(`${NAMESPACE}/appointments`);
    return data;
  },

  getTodayAppointments: async (): Promise<Appointment[]> => {
    // Get today's date in YYYY-MM-DD format for the API filter (Used in Dashboard Home)
    const today = new Date().toISOString().split('T')[0];
    const { data } = await apiClient.get(`${NAMESPACE}/appointments`, {
      params: { date: today }
    });
    return data;
  },

  getAvailableSlots: async (date: string, serviceId: number) => {
    const { data } = await apiClient.get(`${NAMESPACE}/available-slots`, {
      params: { date, service_id: serviceId }
    });
    return data;
  },

  // ==========================================
  // MUTATING APPOINTMENTS
  // ==========================================
  createAppointment: async (payload: CreateAppointmentPayload): Promise<Appointment> => {
    // TRANSLATE FRONTEND KEYS TO BACKEND EXPECTED KEYS
    const backendPayload = {
      product_id: payload.service_id,             // Maps service_id -> product_id
      appointment_date: payload.date,             // Maps date -> appointment_date
      start_time: payload.time_slot,              // Maps time_slot -> start_time
      end_time: payload.time_slot,                // Backend requires end_time, using start_time as fallback
      customer_id: 0,                             // Required by backend
      vendor_id: 0,                               // Backend PHP will auto-resolve this
      status: 'pending',
      // Since PHP currently doesn't have columns for guest name/phone, 
      // we inject them into the 'notes' field so you don't lose the customer's info!
      notes: `نام مشتری: ${payload.customer_name} | تلفن: ${payload.customer_phone}`
    };

    const { data } = await apiClient.post(`${NAMESPACE}/appointments`, backendPayload);
    return data;
  },

  deleteAppointment: async (id: number) => {
    await apiClient.delete(`${NAMESPACE}/appointments/${id}`);
  }
};