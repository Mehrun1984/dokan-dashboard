import { LayoutDashboard, CalendarDays, ShoppingBag, User } from 'lucide-react';

export const vendorNavLinks = [
  { name: 'داشبورد', href: '/dashboard', icon: LayoutDashboard },
  { name: 'نوبت‌دهی', href: '/dashboard/bookings', icon: CalendarDays },
  { name: 'خدمات / محصولات', href: '/dashboard/products', icon: ShoppingBag },
  { name: 'پروفایل', href: '/dashboard/settings', icon: User },
];