'use client';

import React, { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { dokanService } from '@/services/dokan.service';
import { Store, MapPin, Phone, UploadCloud, Link as LinkIcon } from 'lucide-react';

export default function ProfilePage() {
  const { register, handleSubmit, setValue, formState: { isSubmitting } } = useForm();
  const [isLoading, setIsLoading] = useState(true);
  
  // States for handling file uploads seamlessly
  const [avatarFile, setAvatarFile] = useState<File | null>(null);
  const [bannerFile, setBannerFile] = useState<File | null>(null);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const data = await dokanService.getStoreSettings();
      // Populate form
      setValue('store_name', data.store_name);
      setValue('phone', data.phone);
      setValue('address', data.address?.street_1);
      setValue('social.instagram', data.social?.instagram);
      setValue('social.twitter', data.social?.twitter);
    } catch (error) {
      console.error('Failed to load profile', error);
    } finally {
      setIsLoading(false);
    }
  };

  const onSubmit = async (data: any) => {
    try {
      let avatarId = null;
      let bannerId = null;

      // 1. Handle Headless Media Uploads First
      if (avatarFile) {
        avatarId = await dokanService.uploadMedia(avatarFile);
      }
      if (bannerFile) {
        bannerId = await dokanService.uploadMedia(bannerFile);
      }

      // 2. Prepare payload exactly as Dokan expects
      const payload: any = {
        store_name: data.store_name,
        phone: data.phone,
        address: {
          street_1: data.address,
        },
        social: {
          instagram: data.social.instagram,
          twitter: data.social.twitter,
        }
      };

      // Only append media IDs if new files were uploaded
      if (avatarId) payload.gravatar = avatarId;
      if (bannerId) payload.banner = bannerId;

      // 3. Update Settings
      await dokanService.updateStoreSettings(payload);
      alert('پروفایل با موفقیت بروزرسانی شد.');
      
      // Reset file states so we don't re-upload on subsequent saves
      setAvatarFile(null);
      setBannerFile(null);

    } catch (error) {
      alert('خطا در بروزرسانی پروفایل.');
      console.error(error);
    }
  };

  if (isLoading) return <div className="p-8 text-center text-gray-500">در حال بارگذاری...</div>;

  return (
    <div className="space-y-6 pb-24 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold text-gray-900">تنظیمات فروشگاه</h1>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        
        {/* Media Uploads Card */}
        <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm space-y-6">
          <h3 className="font-bold text-lg text-gray-900 flex items-center gap-2 border-b border-gray-50 pb-3">
            <UploadCloud size={20} className="text-blue-600" />
            تصاویر فروشگاه
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">لوگو / آواتار</label>
              <input 
                type="file" 
                accept="image/*"
                onChange={(e) => e.target.files && setAvatarFile(e.target.files[0])}
                className="w-full text-sm text-gray-500 file:me-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
              />
              {avatarFile && <span className="text-xs text-green-600 mt-2 block">فایل انتخاب شد: {avatarFile.name}</span>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">بنر فروشگاه</label>
              <input 
                type="file" 
                accept="image/*"
                onChange={(e) => e.target.files && setBannerFile(e.target.files[0])}
                className="w-full text-sm text-gray-500 file:me-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
              />
              {bannerFile && <span className="text-xs text-green-600 mt-2 block">فایل انتخاب شد: {bannerFile.name}</span>}
            </div>
          </div>
        </div>

        {/* Basic Info Card */}
        <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm space-y-4">
          <h3 className="font-bold text-lg text-gray-900 flex items-center gap-2 border-b border-gray-50 pb-3">
            <Store size={20} className="text-blue-600" />
            اطلاعات پایه
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نام فروشگاه</label>
              <input {...register('store_name')} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">شماره تماس پشتیبانی</label>
              <input dir="ltr" {...register('phone')} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-start" />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1 flex items-center gap-1">
              <MapPin size={16} className="text-gray-400" />
              آدرس کامل
            </label>
            <textarea {...register('address')} rows={3} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 resize-none"></textarea>
          </div>
        </div>

        {/* Social Links Card */}
        <div className="bg-white rounded-2xl p-6 border border-gray-100 shadow-sm space-y-4">
          <h3 className="font-bold text-lg text-gray-900 flex items-center gap-2 border-b border-gray-50 pb-3">
            <LinkIcon size={20} className="text-blue-600" />
            شبکه‌های اجتماعی
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">لینک اینستاگرام</label>
              <input dir="ltr" placeholder="https://instagram.com/..." {...register('social.instagram')} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-start" />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">لینک ایکس (توییتر)</label>
              <input dir="ltr" placeholder="https://x.com/..." {...register('social.twitter')} className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-start" />
            </div>
          </div>
        </div>

        {/* Submit Actions */}
        <div className="bg-white border-t border-gray-200 p-4 fixed bottom-16 inset-x-0 md:static md:bg-transparent md:border-0 md:p-0 z-40">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full md:w-auto md:px-8 py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl disabled:opacity-70 transition-colors flex justify-center items-center mx-auto md:ms-0"
          >
            {isSubmitting ? 'در حال ذخیره اطلاعات...' : 'ذخیره تغییرات فروشگاه'}
          </button>
        </div>

      </form>
    </div>
  );
}