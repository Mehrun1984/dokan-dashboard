'use client';

import React, { useEffect, useState } from 'react';
import { dokanService } from '@/services/dokan.service';
import { ShoppingBag, ChevronDown, CheckCircle, Clock } from 'lucide-react';

const ORDER_STATUSES = [
  { value: 'wc-pending', label: 'در انتظار پرداخت' },
  { value: 'wc-processing', label: 'در حال انجام' },
  { value: 'wc-contacted', label: 'تماس گرفته شد' }, // Custom Status
  { value: 'wc-completed', label: 'تکمیل شده' },
  { value: 'wc-cancelled', label: 'لغو شده' },
];

export default function OrdersPage() {
  const [orders, setOrders] = useState<any[]>([]);
  const [expandedOrderId, setExpandedOrderId] = useState<number | null>(null);
  const [isUpdating, setIsUpdating] = useState(false);

  useEffect(() => {
    fetchOrders();
  }, []);

  const fetchOrders = async () => {
    try {
      const data = await dokanService.getOrders();
      setOrders(data);
    } catch (error) {
      console.error('Failed to load orders', error);
    }
  };

  const handleStatusChange = async (orderId: number, newStatus: string) => {
    try {
      setIsUpdating(true);
      await dokanService.updateOrderStatus(orderId, newStatus);
      setOrders(orders.map(o => o.id === orderId ? { ...o, status: newStatus.replace('wc-', '') } : o));
      alert('وضعیت سفارش بروزرسانی شد.');
    } catch (error) {
      alert('خطا در بروزرسانی وضعیت.');
    } finally {
      setIsUpdating(false);
    }
  };

  const getStatusLabel = (status: string) => {
    const match = ORDER_STATUSES.find(s => s.value.includes(status));
    return match ? match.label : status;
  };

  return (
    <div className="space-y-6 pb-24 relative min-h-[80vh]">
      <h1 className="text-2xl font-bold text-gray-900">سفارشات مشتریان</h1>

      <div className="grid grid-cols-1 gap-4">
        {orders.map((order) => {
          const isExpanded = expandedOrderId === order.id;

          return (
            <div key={order.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm overflow-hidden">
              {/* Card Header (Always Visible) */}
              <div 
                className="p-5 flex items-center justify-between cursor-pointer hover:bg-gray-50 transition-colors"
                onClick={() => setExpandedOrderId(isExpanded ? null : order.id)}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-xl flex items-center justify-center">
                    <ShoppingBag size={24} />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900">سفارش #{order.id}</h4>
                    <p className="text-sm text-gray-500">{order.shipping?.first_name} {order.shipping?.last_name}</p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <span className="font-semibold text-gray-900">{Number(order.total).toLocaleString('fa-IR')} تومان</span>
                  <span className="text-xs px-2 py-1 bg-gray-100 text-gray-600 rounded-md">
                    {getStatusLabel(order.status)}
                  </span>
                </div>
              </div>

              {/* Card Details (Expandable) */}
              {isExpanded && (
                <div className="p-5 border-t border-gray-100 bg-gray-50/50 space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    
                    <div className="space-y-1">
                      <p className="text-sm text-gray-600"><span className="font-medium">تاریخ:</span> {new Date(order.date_created).toLocaleDateString('fa-IR')}</p>
                      <p className="text-sm text-gray-600"><span className="font-medium">موبایل:</span> <span dir="ltr">{order.billing?.phone}</span></p>
                    </div>

                    <div className="flex items-center gap-2 w-full sm:w-auto">
                      <label className="text-sm font-medium text-gray-700 whitespace-nowrap">تغییر وضعیت:</label>
                      <select 
                        disabled={isUpdating}
                        value={`wc-${order.status}`}
                        onChange={(e) => handleStatusChange(order.id, e.target.value)}
                        className="w-full sm:w-48 px-3 py-2 bg-white border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                      >
                        {ORDER_STATUSES.map(s => (
                          <option key={s.value} value={s.value}>{s.label}</option>
                        ))}
                      </select>
                    </div>

                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}