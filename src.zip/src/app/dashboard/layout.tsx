import React from 'react';
import Sidebar from '@/components/layout/Sidebar';
import BottomNav from '@/components/layout/BottomNav';

export default function VendorLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Sidebar />
      
      {/* 
        Main content wrapper. 
        - Mobile: padding bottom to clear the BottomNav (pb-20).
        - Desktop: logical margin start (ms-64) to clear the expanded Sidebar.
        (Note: If you implement a global state for the sidebar collapse, 
        you can dynamically switch this between ms-20 and ms-64) 
      */}
      <main className="flex-1 pb-20 md:pb-0 md:ms-64 transition-all duration-300">
        {/* Optional Top Header for Mobile */}
        <header className="md:hidden bg-white h-16 flex items-center px-4 border-b border-gray-200 sticky top-0 z-40 shadow-sm">
          <h1 className="font-bold text-lg text-gray-800">داشبورد فروشنده</h1>
        </header>

        <div className="p-4 md:p-8 max-w-7xl mx-auto">
          {children}
        </div>
      </main>

      <BottomNav />
    </div>
  );
}