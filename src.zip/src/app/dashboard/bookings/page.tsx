'use client';

import React, { useEffect, useState } from 'react';
import { bookingService, Appointment } from '@/services/booking.service';
import NewAppointmentModal from '@/components/bookings/NewAppointmentModal';
import { CalendarDays, Clock, User, Plus, Calendar } from 'lucide-react';

export default function AppointmentsPage() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const fetchAppointments = async () => {
    try {
      setIsLoading(true);
      const data = await bookingService.getAppointments();
      setAppointments(Array.isArray(data) ? data : ((data as any)?.appointments || []));
    } catch (error) {
      console.error('Failed to load appointments', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  return (
    <div className="space-y-6 pb-24 relative min-h-[80vh]">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">نوبت‌های من</h1>
          <p className="text-gray-500 text-sm mt-1">مدیریت نوبت‌ها و رزروهای مشتریان</p>
        </div>
        
        <button 
          onClick={() => setIsModalOpen(true)}
          className="hidden sm:flex items-center gap-2 px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-medium transition-colors"
        >
          <Plus size={20} />
          ثبت نوبت جدید
        </button>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p>در حال دریافت نوبت‌ها...</p>
        </div>
      ) : appointments.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 p-12 flex flex-col items-center text-center">
          <CalendarDays size={48} className="text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-1">نوبتی یافت نشد</h3>
          <p className="text-gray-500">در حال حاضر هیچ نوبت فعالی ندارید.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {appointments.map((apt: any) => {
            // Extract the name and phone from our custom notes string
            let customerName = 'مشتری (بدون نام)';
            let customerPhone = '---';
            
            if (apt.notes && apt.notes.includes('نام مشتری:')) {
              const parts = apt.notes.split('|');
              customerName = parts[0]?.replace('نام مشتری:', '').trim() || customerName;
              customerPhone = parts[1]?.replace('تلفن:', '').trim() || customerPhone;
            } else if (apt.customer_name) {
              customerName = apt.customer_name;
              customerPhone = apt.customer_phone || '---';
            }

            return (
              <div key={apt.id} className="bg-white rounded-2xl border border-gray-100 shadow-sm p-4 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
                
                {/* 1. Customer Info */}
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 bg-blue-50 text-blue-600 rounded-full flex items-center justify-center shrink-0">
                    <User size={20} />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{customerName}</h3>
                    <p className="text-sm text-gray-500 mt-1" dir="ltr">{customerPhone}</p>
                  </div>
                </div>

                {/* 2. Date and Time Info */}
                <div className="flex items-center gap-4 bg-gray-50 px-4 py-3 rounded-xl border border-gray-100">
                  <div className="flex items-center gap-2 text-gray-700">
                    <Calendar size={16} className="text-blue-500" />
                    {/* Read the correct backend date field */}
                    <span className="text-sm font-medium">{apt.appointment_date || 'بدون تاریخ'}</span>
                  </div>
                  
                  <div className="w-px h-5 bg-gray-300"></div>
                  
                  <div className="flex items-center gap-2 text-gray-700">
                    <Clock size={16} className="text-blue-500" />
                    {/* Format the correct backend time field */}
                    <span className="text-sm font-mono font-bold" dir="ltr">
                      {apt.start_time ? apt.start_time.substring(0, 5) : '--:--'}
                    </span>
                  </div>
                </div>

                {/* Optional Status Badge */}
                <div>
                  <span className={`text-xs px-3 py-1 rounded-full font-medium ${
                    apt.status === 'pending' ? 'bg-orange-50 text-orange-600' :
                    apt.status === 'cancelled' ? 'bg-red-50 text-red-600' :
                    'bg-green-50 text-green-600'
                  }`}>
                    {apt.status === 'pending' ? 'در انتظار' : 
                     apt.status === 'cancelled' ? 'لغو شده' : 'تایید شده'}
                  </span>
                </div>

              </div>
            );
          })}
        </div>
      )}

      <button
        onClick={() => setIsModalOpen(true)}
        className="sm:hidden fixed bottom-24 end-6 w-14 h-14 bg-blue-600 text-white rounded-full shadow-lg flex items-center justify-center active:scale-95 transition-transform z-40"
      >
        <Plus size={28} />
      </button>

      <NewAppointmentModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onSuccess={fetchAppointments} 
      />
    </div>
  );
}