'use client';

import React, { useEffect, useState } from 'react';
import { DokanProduct } from '@/types/dokan';
import { dokanService } from '@/services/dokan.service';
import EditPriceModal from '@/components/products/EditPriceModal';
import { Edit2, PackageSearch } from 'lucide-react';
import Image from 'next/image';

export default function ProductsPage() {
  const [products, setProducts] = useState<DokanProduct[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  
  // Modal State
  const [selectedProduct, setSelectedProduct] = useState<DokanProduct | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      setIsLoading(true);
      const data = await dokanService.getProducts();
      setProducts(data);
    } catch (error) {
      console.error('Failed to load products', error);
    } finally {
      setIsLoading(false);
    }
  };

  const openEditModal = (product: DokanProduct) => {
    setSelectedProduct(product);
    setIsModalOpen(true);
  };

  // Callback to update UI instantly without re-fetching everything
  const handleProductUpdated = (updatedProduct: DokanProduct) => {
    setProducts((prev) => 
      prev.map((p) => p.id === updatedProduct.id ? updatedProduct : p)
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">خدمات و محصولات من</h1>
      </div>

      {isLoading ? (
        <div className="flex flex-col items-center justify-center py-20 text-gray-400">
          <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p>در حال بارگذاری اطلاعات...</p>
        </div>
      ) : products.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-200 p-12 flex flex-col items-center text-center">
          <PackageSearch size={48} className="text-gray-300 mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-1">هیچ محصولی یافت نشد</h3>
          <p className="text-gray-500">شما هنوز هیچ خدمت یا محصولی ثبت نکرده‌اید.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {products.map((product) => (
            <div key={product.id} className="bg-white rounded-2xl border border-gray-200 overflow-hidden shadow-sm hover:shadow-md transition-shadow">
              
              {/* Product Header: Image & Title */}
              <div className="flex items-start p-4 gap-4 border-b border-gray-50">
                <div className="w-16 h-16 rounded-xl bg-gray-100 overflow-hidden relative flex-shrink-0">
                  {product.images?.[0]?.src ? (
                    <Image 
                      src={product.images[0].src} 
                      alt={product.name} 
                      fill
                      className="object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">بدون عکس</div>
                  )}
                </div>
                <div className="flex-1 min-w-0 pt-1">
                  <h3 className="text-gray-900 font-bold text-base truncate">{product.name}</h3>
                  <p className="text-gray-500 text-xs mt-1 truncate">
                    {product.categories.map((c: any) => c.name).join('، ')}
                  </p>
                </div>
              </div>

              {/* Product Body: Prices */}
              <div className="p-4 bg-gray-50/50">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-gray-500 text-sm">قیمت اصلی:</span>
                  <span className="text-gray-900 font-semibold">{Number(product.regular_price).toLocaleString('fa-IR')} تومان</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-gray-500 text-sm">قیمت حراج:</span>
                  <span className="text-red-600 font-semibold">
                    {product.sale_price ? `${Number(product.sale_price).toLocaleString('fa-IR')} تومان` : '-'}
                  </span>
                </div>
              </div>

              {/* Product Footer: Action */}
              <div className="p-3 border-t border-gray-100">
                <button 
                  onClick={() => openEditModal(product)}
                  className="w-full py-2 flex items-center justify-center gap-2 text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg font-medium transition-colors"
                >
                  <Edit2 size={16} />
                  ویرایش قیمت
                </button>
              </div>

            </div>
          ))}
        </div>
      )}

      {/* The Edit Modal */}
      <EditPriceModal 
        isOpen={isModalOpen}
        product={selectedProduct}
        onClose={() => setIsModalOpen(false)}
        onSuccess={handleProductUpdated}
      />
    </div>
  );
}