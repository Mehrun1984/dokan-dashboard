import type { Metadata, Viewport } from "next";
import { Vazirmatn } from 'next/font/google'; // Excellent Persian font
import "./globals.css";

// Using Vazirmatn for highly readable Persian text
const vazirmatn = Vazirmatn({ subsets: ['arabic'], display: 'swap' });

export const metadata: Metadata = {
  title: 'پنل فروشندگان | Vendor Dashboard',
  description: 'PWA Vendor Dashboard for Beauty Services',
  manifest: '/manifest.json', // Your PWA manifest
};

export const viewport: Viewport = {
  themeColor: '#ffffff',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="fa" dir="rtl" className={vazirmatn.className}>
      <body className="bg-gray-50 text-gray-900 antialiased">
        {children}
      </body>
    </html>
  );
}
