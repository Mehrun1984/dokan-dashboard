'use client';

import React, { useState } from 'react';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { zodResolver } from '@hookform/resolvers/zod';
import { bookingService } from '@/services/booking.service';
import { X, AlertCircle } from 'lucide-react';

const bookingSchema = z.object({
  customer_name: z.string().min(2, 'نام مشتری الزامی است'),
  customer_phone: z.string().regex(/^(\+98|0)?9\d{9}$/, 'شماره موبایل معتبر نیست'),
  service_id: z.coerce.number().min(1, 'انتخاب خدمت الزامی است'),
  date: z.string().min(1, 'تاریخ الزامی است'),
  time_slot: z.string().min(1, 'ساعت الزامی است'),
});

type BookingFormData = z.infer<typeof bookingSchema>;

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export default function NewAppointmentModal({ isOpen, onClose, onSuccess }: Props) {
  const [error, setError] = useState<string | null>(null);
  
  const { register, handleSubmit, reset, formState: { errors, isSubmitting } } = useForm<BookingFormData>({
    resolver: zodResolver(bookingSchema),
  });

  if (!isOpen) return null;

  const onSubmit = async (data: BookingFormData) => {
    setError(null);

    try {
      await bookingService.createAppointment(data);
      alert('نوبت با موفقیت ثبت شد و فاکتور متناظر در سیستم ایجاد گردید.'); 
      reset();
      onSuccess(); 
      onClose(); 
    } catch (err: any) {
      console.error('Booking Transaction Failed:', err);
      setError(err.response?.data?.message || 'خطا در ثبت نوبت. لطفا دوباره تلاش کنید.');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center bg-black/50 p-0 sm:p-4 backdrop-blur-sm">
      <div className="bg-white w-full sm:max-w-md rounded-t-3xl sm:rounded-2xl shadow-xl flex flex-col max-h-[90vh] animate-slide-up sm:animate-fade-in">
        
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <h3 className="font-bold text-lg text-gray-900">ثبت نوبت جدید</h3>
          <button onClick={onClose} className="p-2 bg-gray-50 text-gray-500 rounded-full hover:bg-gray-100 transition-colors">
            <X size={20} />
          </button>
        </div>

        <div className="p-6 overflow-y-auto">
          {error && (
            <div className="mb-4 p-3 bg-red-50 text-red-600 rounded-xl text-sm font-medium flex items-start gap-2">
              <AlertCircle size={18} className="shrink-0 mt-0.5" />
              <p>{error}</p>
            </div>
          )}

          <form id="booking-form" onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">نام مشتری</label>
              <input 
                {...register('customer_name')} 
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" 
                placeholder="نام و نام خانوادگی" 
              />
              {errors.customer_name && <span className="text-red-500 text-xs mt-1 block">{errors.customer_name.message}</span>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">شماره موبایل</label>
              <input 
                type="tel" 
                dir="ltr" 
                {...register('customer_phone')} 
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-start" 
                placeholder="09123456789" 
              />
              {errors.customer_phone && <span className="text-red-500 text-xs mt-1 block text-start">{errors.customer_phone.message}</span>}
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">تاریخ</label>
                <input 
                  type="date" 
                  {...register('date')} 
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" 
                />
                {errors.date && <span className="text-red-500 text-xs mt-1 block">{errors.date.message}</span>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">ساعت</label>
                <input 
                  type="time" 
                  {...register('time_slot')} 
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500" 
                />
                {errors.time_slot && <span className="text-red-500 text-xs mt-1 block">{errors.time_slot.message}</span>}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">شناسه خدمت / محصول</label>
              <input 
                type="number" 
                dir="ltr" 
                {...register('service_id')} 
                className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:ring-2 focus:ring-blue-500 text-start" 
              />
              {errors.service_id && <span className="text-red-500 text-xs mt-1 block text-start">{errors.service_id.message}</span>}
            </div>
          </form>
        </div>

        <div className="px-6 py-4 border-t border-gray-100 bg-white pb-safe">
          <button
            type="submit"
            form="booking-form"
            disabled={isSubmitting}
            className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-xl disabled:opacity-70 flex justify-center items-center transition-colors"
          >
            {isSubmitting ? 'در حال ثبت...' : 'ثبت نوبت'}
          </button>
        </div>

      </div>
    </div>
  );
}